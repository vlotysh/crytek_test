<?php

namespace Crytek\Test;

class Listener {

    public function onTestEvent(...$arguments) {

    }

}


require(["pages"], function (pages) {
    
    //initial current page
    pages.settings.init();
    
});